﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.2.4),
    on oktober 01, 2020, at 12:00
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.2.4'
expName = 'StroopExperiment'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sort_keys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\lien\\Desktop\\Chapter 1\\StroopTask\\StroopExperiment_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
WelcomeText = visual.TextStim(win=win, name='WelcomeText',
    text='In this experiment you will see color words (“red”, “blue”, “green” and “yellow”) presented in a random ink color (red, blue, green and yellow color). You have to respond to the ink color of the stimulus and ignore the meaning of the written word. You can use the following four response buttons (from left to right; use the index and middle finger of your left and right hand): “d”,“f”,“j” and “k”. If the ink color is red, press the leftmost button “d”. If it’s blue, press “f”. If it’s green, press “j”. If it’s yellow, press “k”. Answer as quickly as possible, but also try to avoid mistakes. By all means ignore the meaning of the words, you should only respond to the ink color. Any questions?',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
WelcomeResp = keyboard.Keyboard()

# Initialize components for Routine "Task"
TaskClock = core.Clock()
StroopStimulus = visual.TextStim(win=win, name='StroopStimulus',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
Response = keyboard.Keyboard()

# Initialize components for Routine "Goodbye"
GoodbyeClock = core.Clock()
GoodbyeText = visual.TextStim(win=win, name='GoodbyeText',
    text='Goodbye!',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
GoodbyeResp = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Welcome"-------
continueRoutine = True
# update component parameters for each repeat
WelcomeResp.keys = []
WelcomeResp.rt = []
_WelcomeResp_allKeys = []
# keep track of which components have finished
WelcomeComponents = [WelcomeText, WelcomeResp]
for thisComponent in WelcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
WelcomeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Welcome"-------
while continueRoutine:
    # get current time
    t = WelcomeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=WelcomeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *WelcomeText* updates
    if WelcomeText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        WelcomeText.frameNStart = frameN  # exact frame index
        WelcomeText.tStart = t  # local t and not account for scr refresh
        WelcomeText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(WelcomeText, 'tStartRefresh')  # time at next scr refresh
        WelcomeText.setAutoDraw(True)
    
    # *WelcomeResp* updates
    waitOnFlip = False
    if WelcomeResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        WelcomeResp.frameNStart = frameN  # exact frame index
        WelcomeResp.tStart = t  # local t and not account for scr refresh
        WelcomeResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(WelcomeResp, 'tStartRefresh')  # time at next scr refresh
        WelcomeResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(WelcomeResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(WelcomeResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if WelcomeResp.status == STARTED and not waitOnFlip:
        theseKeys = WelcomeResp.getKeys(keyList=['space'], waitRelease=False)
        _WelcomeResp_allKeys.extend(theseKeys)
        if len(_WelcomeResp_allKeys):
            WelcomeResp.keys = _WelcomeResp_allKeys[-1].name  # just the last key pressed
            WelcomeResp.rt = _WelcomeResp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('WelcomeText.started', WelcomeText.tStartRefresh)
thisExp.addData('WelcomeText.stopped', WelcomeText.tStopRefresh)
# check responses
if WelcomeResp.keys in ['', [], None]:  # No response was made
    WelcomeResp.keys = None
thisExp.addData('WelcomeResp.keys',WelcomeResp.keys)
if WelcomeResp.keys != None:  # we had a response
    thisExp.addData('WelcomeResp.rt', WelcomeResp.rt)
thisExp.addData('WelcomeResp.started', WelcomeResp.tStartRefresh)
thisExp.addData('WelcomeResp.stopped', WelcomeResp.tStopRefresh)
thisExp.nextEntry()
# the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
TrialLoop = data.TrialHandler(nReps=2, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('ExperimentalDesign.xlsx'),
    seed=None, name='TrialLoop')
thisExp.addLoop(TrialLoop)  # add the loop to the experiment
thisTrialLoop = TrialLoop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrialLoop.rgb)
if thisTrialLoop != None:
    for paramName in thisTrialLoop:
        exec('{} = thisTrialLoop[paramName]'.format(paramName))

for thisTrialLoop in TrialLoop:
    currentLoop = TrialLoop
    # abbreviate parameter names if possible (e.g. rgb = thisTrialLoop.rgb)
    if thisTrialLoop != None:
        for paramName in thisTrialLoop:
            exec('{} = thisTrialLoop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Task"-------
    continueRoutine = True
    # update component parameters for each repeat
    StroopStimulus.setColor(FontColor, colorSpace='rgb')
    StroopStimulus.setText(ColorWord)
    Response.keys = []
    Response.rt = []
    _Response_allKeys = []
    # keep track of which components have finished
    TaskComponents = [StroopStimulus, Response]
    for thisComponent in TaskComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    TaskClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Task"-------
    while continueRoutine:
        # get current time
        t = TaskClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=TaskClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *StroopStimulus* updates
        if StroopStimulus.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            StroopStimulus.frameNStart = frameN  # exact frame index
            StroopStimulus.tStart = t  # local t and not account for scr refresh
            StroopStimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(StroopStimulus, 'tStartRefresh')  # time at next scr refresh
            StroopStimulus.setAutoDraw(True)
        if StroopStimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > StroopStimulus.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                StroopStimulus.tStop = t  # not accounting for scr refresh
                StroopStimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(StroopStimulus, 'tStopRefresh')  # time at next scr refresh
                StroopStimulus.setAutoDraw(False)
        
        # *Response* updates
        waitOnFlip = False
        if Response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Response.frameNStart = frameN  # exact frame index
            Response.tStart = t  # local t and not account for scr refresh
            Response.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Response, 'tStartRefresh')  # time at next scr refresh
            Response.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(Response.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(Response.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if Response.status == STARTED and not waitOnFlip:
            theseKeys = Response.getKeys(keyList=['d', 'f', 'j', 'k'], waitRelease=False)
            _Response_allKeys.extend(theseKeys)
            if len(_Response_allKeys):
                Response.keys = _Response_allKeys[-1].name  # just the last key pressed
                Response.rt = _Response_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TaskComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Task"-------
    for thisComponent in TaskComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    TrialLoop.addData('StroopStimulus.started', StroopStimulus.tStartRefresh)
    TrialLoop.addData('StroopStimulus.stopped', StroopStimulus.tStopRefresh)
    # check responses
    if Response.keys in ['', [], None]:  # No response was made
        Response.keys = None
    TrialLoop.addData('Response.keys',Response.keys)
    if Response.keys != None:  # we had a response
        TrialLoop.addData('Response.rt', Response.rt)
    TrialLoop.addData('Response.started', Response.tStartRefresh)
    TrialLoop.addData('Response.stopped', Response.tStopRefresh)
    # the Routine "Task" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 2 repeats of 'TrialLoop'


# ------Prepare to start Routine "Goodbye"-------
continueRoutine = True
# update component parameters for each repeat
GoodbyeResp.keys = []
GoodbyeResp.rt = []
_GoodbyeResp_allKeys = []
# keep track of which components have finished
GoodbyeComponents = [GoodbyeText, GoodbyeResp]
for thisComponent in GoodbyeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
GoodbyeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Goodbye"-------
while continueRoutine:
    # get current time
    t = GoodbyeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=GoodbyeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *GoodbyeText* updates
    if GoodbyeText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        GoodbyeText.frameNStart = frameN  # exact frame index
        GoodbyeText.tStart = t  # local t and not account for scr refresh
        GoodbyeText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(GoodbyeText, 'tStartRefresh')  # time at next scr refresh
        GoodbyeText.setAutoDraw(True)
    
    # *GoodbyeResp* updates
    waitOnFlip = False
    if GoodbyeResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        GoodbyeResp.frameNStart = frameN  # exact frame index
        GoodbyeResp.tStart = t  # local t and not account for scr refresh
        GoodbyeResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(GoodbyeResp, 'tStartRefresh')  # time at next scr refresh
        GoodbyeResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(GoodbyeResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(GoodbyeResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if GoodbyeResp.status == STARTED and not waitOnFlip:
        theseKeys = GoodbyeResp.getKeys(keyList=['space'], waitRelease=False)
        _GoodbyeResp_allKeys.extend(theseKeys)
        if len(_GoodbyeResp_allKeys):
            GoodbyeResp.keys = _GoodbyeResp_allKeys[-1].name  # just the last key pressed
            GoodbyeResp.rt = _GoodbyeResp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in GoodbyeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Goodbye"-------
for thisComponent in GoodbyeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('GoodbyeText.started', GoodbyeText.tStartRefresh)
thisExp.addData('GoodbyeText.stopped', GoodbyeText.tStopRefresh)
# check responses
if GoodbyeResp.keys in ['', [], None]:  # No response was made
    GoodbyeResp.keys = None
thisExp.addData('GoodbyeResp.keys',GoodbyeResp.keys)
if GoodbyeResp.keys != None:  # we had a response
    thisExp.addData('GoodbyeResp.rt', GoodbyeResp.rt)
thisExp.addData('GoodbyeResp.started', GoodbyeResp.tStartRefresh)
thisExp.addData('GoodbyeResp.stopped', GoodbyeResp.tStopRefresh)
thisExp.nextEntry()
# the Routine "Goodbye" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
